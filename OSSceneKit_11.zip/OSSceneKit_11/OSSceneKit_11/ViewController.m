//
//  ViewController.m
//  OSSceneKit_11
//
//  Created by xu jie on 16/9/12.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    [self addAdView];
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addSCNView{
    // 创建资源类
    
    SCNSceneSource *sceneSource = [SCNSceneSource sceneSourceWithURL:[[NSBundle mainBundle] URLForResource:@"skinning" withExtension:@"dae"] options:nil];
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.allowsCameraControl = true;
    scnView.backgroundColor = [UIColor blackColor];
    scnView.scene  = [sceneSource sceneWithOptions:nil error:nil];
    // 获取模型包含的动画组
    NSArray *animationIDs =  [sceneSource identifiersOfEntriesWithClass:[CAAnimation class]];
    NSUInteger animationCount = [animationIDs count];
    NSMutableArray *longAnimations = [[NSMutableArray alloc] initWithCapacity:animationCount];
    CFTimeInterval maxDuration = 0;
    for (NSInteger index = 0; index < animationCount; index++) {
        CAAnimation *animation = [sceneSource entryWithIdentifier:animationIDs[index] withClass:[CAAnimation class]];
        if (animation) {
            maxDuration = MAX(maxDuration, animation.duration);
             NSLog(@"%f",animation.duration);
            [longAnimations addObject:animation];
        }
    }
    
//    SCNNode *cameraNode = [SCNNode node];
//    cameraNode.camera = [SCNCamera camera];
//    cameraNode.camera.automaticallyAdjustsZRange = true;
//    cameraNode.position = SCNVector3Make(0, -500, 0);
//    cameraNode.rotation = SCNVector4Make(1, 0, 0, M_PI/2.0);
//    scnView.pointOfView = cameraNode;
//    
//    [scnView.scene.rootNode addChildNode:cameraNode];
    
    
    
    CAAnimationGroup *longAnimationsGroup = [[CAAnimationGroup alloc] init];
    longAnimationsGroup.animations = longAnimations;
    longAnimationsGroup.duration = maxDuration;
  
   
   
    
   
    CAAnimationGroup *idleAnimationGroup = [longAnimationsGroup copy];
    idleAnimationGroup.timeOffset = 20 ;//6.45833333333333
    
     CAAnimationGroup *lastAnimationGroup;
    lastAnimationGroup = [CAAnimationGroup animation];
    lastAnimationGroup.animations = @[idleAnimationGroup];
    //lastAnimationGroup.timeOffset = 20;
    lastAnimationGroup.duration = 24.71 -20;
    lastAnimationGroup.repeatCount = 10000;
    lastAnimationGroup.autoreverses = YES;
    
    SCNNode *personNode = [scnView.scene.rootNode childNodeWithName:@"avatar_attach" recursively:YES];
    
    SCNNode *skeletonNode = [scnView.scene.rootNode childNodeWithName:@"skeleton" recursively:YES];
    
    //cNode.physicsBody = [SCNPhysicsBody kinematicBody];
   
    
    [ personNode addAnimation:lastAnimationGroup forKey:@"animation"];
   
  
    
    

//    });
    
   
    // 查看骨头
    
    [self visualizeBones:true ofNode:skeletonNode inheritedScale:1];

    [self.view addSubview:scnView];
    
    
    
}

- (void)applyGhostEffect:(BOOL)show onNode:(SCNNode *)node
{
    
    [node.geometry setValue:@(show) forKey:@"ghostFactor"];
    
    for (SCNNode *child in node.childNodes)
        [self applyGhostEffect:show onNode:child];
}

- (void)setShaderModifiers:(NSDictionary *)modifiers onNode:(SCNNode *)node
{
    node.geometry.shaderModifiers = modifiers;
    
    for (SCNNode *childNode in node.childNodes)
        [self setShaderModifiers:modifiers onNode:childNode];
}


#pragma mark - Skeleton visualisation



- (void)visualizeBones:(BOOL)show ofNode:(SCNNode *)node inheritedScale:(CGFloat)scale
{
    // We propagate an inherited scale so that the boxes
    // representing the bones will be of the same size
    scale *= node.scale.x;
    
    if (show) {
        if (node.geometry == nil)
            node.geometry = [SCNBox boxWithWidth:6.0 / scale height:6.0 / scale length:6.0 / scale chamferRadius:0.5];
    }
    else {
        if ([node.geometry isKindOfClass:[SCNBox class]])
            node.geometry = nil;
    }
    
    for (SCNNode *child in node.childNodes)
        [self visualizeBones:show ofNode:child inheritedScale:scale];
}

@end
