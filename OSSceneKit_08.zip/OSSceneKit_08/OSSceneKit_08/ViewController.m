//
//  ViewController.m
//  OSSceneKit_08
//
//  Created by xu jie on 16/9/9.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()
@property(nonatomic,strong)SCNView *scnView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
  
  
}


// 添加视
- (void)addSCNView{
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds options:@{SCNPreferLowPowerDeviceKey:@(true)}];
   
    //scnView.antialiasingMode = SCNAntialiasingModeMultisampling4X;
    self.scnView = scnView;
    if (scnView.eaglContext){
        NSLog(@"OpenGL");
        
    }else{
        NSLog(@"metal");
    }
    
    NSLog(@"%@",scnView.eaglContext);
    
    scnView.backgroundColor = [UIColor blackColor];
    scnView.scene = [SCNScene scene];
    scnView.scene.physicsWorld.speed = 5;
    scnView.showsStatistics = true;
    scnView.allowsCameraControl = true;
    scnView.preferredFramesPerSecond = 60;
    [self.view addSubview:scnView];
    NSLog(@"x:%f",scnView.scene.physicsWorld.gravity.x);
     NSLog(@"y:%f",scnView.scene.physicsWorld.gravity.y);
     NSLog(@"z:%f",scnView.scene.physicsWorld.gravity.z);
    
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.position = SCNVector3Make(0, 10, 20);
    cameraNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/8.0);
    cameraNode.camera = [SCNCamera camera];
    cameraNode.camera.automaticallyAdjustsZRange = true;
    [scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加一个地板
    
    SCNFloor *floor = [SCNFloor floor];
    floor.firstMaterial.diffuse.contents = @"floor.jpg";
    SCNNode *floorNode = [SCNNode nodeWithGeometry:floor];
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    [scnView.scene.rootNode addChildNode:floorNode];
    
    for(int i = 0; i < 20 ;i++){
        SCNNode *node = [self createStaticBox];
        [scnView.scene.rootNode addChildNode:node];
    }
    
    // 添加静态的物理身体
    
    
    // 添加动态的物理身体
    
    for(int i = 0; i < 9 ;i++){
        SCNNode *node = [self creatkinematicBody];
        [scnView.scene.rootNode addChildNode:node];
      
    }
    //
    
//    for(int i = 0; i < 9 ;i++){
//        SCNNode *node = [self creatkinematicBody];
//        [scnView.scene.rootNode addChildNode:node];
//    }
    
    // 添加截屏功能
    

    
}
//-(void)snap:(UIButton*)button{
//    [button setBackgroundImage:[self.scnView snapshot] forState:UIControlStateNormal];
//    [self.scnView pause:button];
//   
//    
//}

-(SCNNode*)createStaticBox{
  
    SCNBox *box = [SCNBox boxWithWidth:0.5 height:3 length:1 chamferRadius:0];
    box.firstMaterial.diffuse.contents = @"1.PNG";
    SCNNode *boxNode = [SCNNode nodeWithGeometry:box];
    
    // 静态身体
    boxNode.physicsBody = [SCNPhysicsBody dynamicBody];
    boxNode.position = SCNVector3Make(arc4random_uniform(5)-2, 1.5, arc4random_uniform(5));
    return boxNode;
}

-(SCNNode *)createDynamicBox{
    SCNSphere *sphere = [SCNSphere sphereWithRadius:1];
    SCNNode *sphereNode = [SCNNode nodeWithGeometry:sphere];
    sphere.firstMaterial.diffuse.contents = @"sun.jpg";
    // 静态身体
    sphereNode.physicsBody = [SCNPhysicsBody dynamicBody];
    sphereNode.position = SCNVector3Make(arc4random_uniform(5)-2, 10, arc4random_uniform(5));
    return sphereNode;
}

-(SCNNode *)creatkinematicBody{
    SCNSphere *sphere = [SCNSphere sphereWithRadius:1];
    SCNNode *sphereNode = [SCNNode nodeWithGeometry:sphere];
    sphere.firstMaterial.diffuse.contents = @"sun.jpg";
    // 静态身体
    sphereNode.physicsBody = [SCNPhysicsBody kinematicBody];
    sphereNode.position = SCNVector3Make(arc4random_uniform(5)-2, 10, arc4random_uniform(5));
    SCNAction * move = [SCNAction moveTo:SCNVector3Make(sphereNode.position.x, 0, sphereNode.position.z) duration:5];
    [sphereNode runAction:move];
    return sphereNode;
}



@end
