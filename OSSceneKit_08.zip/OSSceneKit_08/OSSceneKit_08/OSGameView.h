//
//  OSGameView.h
//  OSSceneKit_08
//
//  Created by xu jie on 16/9/9.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <SceneKit/SceneKit.h>

@interface OSGameView : SCNView

@end
