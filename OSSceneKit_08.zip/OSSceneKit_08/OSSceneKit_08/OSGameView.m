//
//  OSGameView.m
//  OSSceneKit_08
//
//  Created by xu jie on 16/9/9.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "OSGameView.h"

@implementation OSGameView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
