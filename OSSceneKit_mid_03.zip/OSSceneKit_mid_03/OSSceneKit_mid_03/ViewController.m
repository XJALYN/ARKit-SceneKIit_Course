//
//  ViewController.m
//  OSSceneKit_mid_03
//
//  Created by xu jie on 16/9/13.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()
@property (weak, nonatomic) IBOutlet SCNView *scnView;

@property(nonatomic,strong)SCNNode *firstViewCamera;
@property(nonatomic,strong)SCNNode *thirdViewCamera;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUp];
    [self addAdView];
    
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

-(void)setUp{
    self.scnView.scene = [SCNScene scene];
    self.scnView.backgroundColor = [UIColor blackColor];
    
    // 创建太阳
    
    SCNNode *sunNode = [SCNNode node];
    sunNode.geometry = [SCNSphere sphereWithRadius:3];
    sunNode.geometry.firstMaterial.diffuse.contents = @"sun.jpg";
    [self.scnView.scene.rootNode addChildNode:sunNode];
    
    SCNAction *sunRotate = [SCNAction repeatActionForever:[SCNAction rotateByAngle:0.1 aroundAxis:SCNVector3Make(0, 1, 0) duration:0.3]];
    [sunNode runAction:sunRotate];
    
    // 设置一个月球系节点
    
    SCNNode *earthMoonNode = [SCNNode node];
    earthMoonNode.position = SCNVector3Make(10, 0, 0);
     [sunNode addChildNode:earthMoonNode];
    
    // 创建地球
    SCNNode *earthNode = [SCNNode node];
    earthNode.geometry = [SCNSphere sphereWithRadius:1];
    earthNode.geometry.firstMaterial.diffuse.contents = @"earth.jpg";
    [earthMoonNode  addChildNode:earthNode];
    earthNode.position = SCNVector3Make(0, 0, 0);
    SCNAction *rotation =[SCNAction repeatActionForever:[SCNAction rotateByAngle:0.1 aroundAxis:SCNVector3Make(0, 1, 0) duration:0.05]];
    [earthNode runAction:rotation];
    
   
    
   
    
    // 创建月球
    
    SCNNode *moonNode = [SCNNode node];
    moonNode.geometry = [SCNSphere sphereWithRadius:0.5];
    moonNode.geometry.firstMaterial.diffuse.contents = @"moon.jpg";
    moonNode.position = SCNVector3Make(2, 0, 0);
    [earthNode addChildNode:moonNode];
    

    
  
    
    // 创建第三视角照相机
    self.thirdViewCamera = [SCNNode node];
    self.thirdViewCamera.camera = [SCNCamera camera];
    self.thirdViewCamera.camera.automaticallyAdjustsZRange = true;
    self.thirdViewCamera.position = SCNVector3Make(0, 0, 30);
    [self.scnView.scene.rootNode addChildNode:self.thirdViewCamera];
    
    // 给地球上方添加一个照相机
    
    self.firstViewCamera = [SCNNode node];
    self.firstViewCamera.camera =[SCNCamera camera];
    self.firstViewCamera.position = SCNVector3Make(0, 0, 10);
    [earthMoonNode addChildNode:self.firstViewCamera];
    
     self.scnView.pointOfView = self.thirdViewCamera;
    
    
}

- (IBAction)SelectedCamera:(id)sender {
    self.scnView.pointOfView = self.thirdViewCamera;
    SCNAction *move = [SCNAction moveTo:SCNVector3Make(0, 0, 30) duration:1];
    [self.thirdViewCamera runAction:move];
    
}
- (IBAction)enterEarthMoonSystem:(id)sender {
    self.scnView.pointOfView = self.firstViewCamera;
}

- (IBAction)exitSunSystem:(id)sender {
    
    SCNAction *move = [SCNAction moveTo:SCNVector3Make(0, 0, 400) duration:1];
    [self.thirdViewCamera runAction:move];
}




@end
