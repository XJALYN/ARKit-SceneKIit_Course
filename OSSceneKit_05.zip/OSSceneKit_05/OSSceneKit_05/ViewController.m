//
//  ViewController.m
//  OSSceneKit_05
//
//  Created by xu jie on 16/9/5.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addSCNView{
    
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView .backgroundColor = [UIColor blackColor];
    [self.view addSubview:scnView ];
    //scnView .allowsCameraControl = true; // 开启操纵照相机选项
    scnView.scene = [SCNScene scene];
    
    // 添加照相机
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode =[SCNNode node];
    cameraNode.camera = camera;
    cameraNode.position = SCNVector3Make(0, 0, 50);
    [scnView.scene.rootNode addChildNode:cameraNode];
    
    SCNBox *box = [SCNBox boxWithWidth:10 height:10 length:10 chamferRadius:0];
    box.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
    SCNNode *boxNode =[SCNNode node];
    boxNode.position = SCNVector3Make(0, 0, 0);
    boxNode.geometry = box;
    [scnView .scene.rootNode addChildNode:boxNode];
    
    // 创建动画行为
    SCNAction *rotation = [SCNAction rotateByAngle:10 aroundAxis:SCNVector3Make(0, 1, 0) duration:2];
    SCNAction *moveUp = [SCNAction moveTo:SCNVector3Make(0, 15, 0) duration:1];
    SCNAction *moveDown = [SCNAction moveTo:SCNVector3Make(0, -15, 0) duration:1];
    // 顺序执行的动画
    SCNAction *sequence = [SCNAction sequence:@[moveUp,moveDown]];
    
    // 组合动画的执行
    SCNAction *group = [SCNAction group:@[sequence ,rotation]];
    
    [boxNode runAction:[SCNAction repeatActionForever:group]];
   
}

@end
