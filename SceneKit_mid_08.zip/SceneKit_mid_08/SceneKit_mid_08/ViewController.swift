//
//  ViewController.swift
//  SceneKit_mid_08
//
//  Created by xu jie on 2016/10/15.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit
import GoogleMobileAds;

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        /// 初始化
        setup()
        addADView()
        
    }
    
    func addADView(){
        let bannerView = GADBannerView(frame:CGRect(x: 0, y: self.view.bounds.size.height-50, width: self.view.bounds.size.width, height: 50))
        self.view.addSubview(bannerView);
        bannerView.rootViewController = self
        bannerView.adUnitID = "ca-app-pub-3629819764559170/3550577647"
        bannerView.isAutoloadEnabled = true;
        bannerView.load(GADRequest())
        
    }
    
    //
    func setup(){
        /// 创建游戏专用视图
        let scnView = SCNView(frame: self.view.bounds)
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        
        /// 创建一个场景
        let scene = SCNScene()
        scnView.scene = scene
        
        /// 创建一个照相机
        let cameraNode  = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.camera?.automaticallyAdjustsZRange = true
        cameraNode.position = SCNVector3(x: 0, y: 1000, z: 1000)
        cameraNode.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -Float(M_PI/4))
        scnView.scene?.rootNode.addChildNode(cameraNode)
        
        
        
        /// 添加一个灯罩
        let cone = SCNCone(topRadius: 1, bottomRadius: 25, height: 50)
        cone.radialSegmentCount = 10
        cone.heightSegmentCount = 5
        
        /// 创建一个点光源,然后添加到场景中去
        let spotLight  = SCNNode()
        spotLight.geometry = cone
        spotLight.geometry?.firstMaterial?.emission.contents = UIColor.yellow
        spotLight.position = SCNVector3(0, 0, 0)
        spotLight.light = SCNLight()
        spotLight.light?.type = .spot
        //spotLight.light?.castsShadow = true
        //spotLight.light?.shadowMode = .forward
        spotLight.light?.spotOuterAngle = 30
        
        /// 注意默认为100 ,由于我们将灯的指点放在1000 灯光照射不到那个距离,所以我们需要调节灯光照射的最远距离
        spotLight.light?.zFar = 2000
     
        
        /// 增加一个灯光支点
        let handleSpot = SCNNode()
        handleSpot.position = SCNVector3(0, 1000, 40)
        handleSpot.addChildNode(spotLight)
        scnView.scene?.rootNode.addChildNode(handleSpot)
        /// 增加一个移动的行为给灯光
        let moveRight = SCNAction.move(to:SCNVector3(100, 1000, 40) , duration: 2)
        let moveLeft = SCNAction.move(to:SCNVector3(-100, 1000, 40) , duration: 2)
        let sequence = SCNAction.sequence([moveLeft,moveRight])
        handleSpot.runAction(SCNAction.repeatForever(sequence))
        
        
        /// 让灯光执行书
        
        let ambient = SCNNode()
        ambient.light = SCNLight()
        ambient.light?.type = .ambient
        scene.rootNode.addChildNode(ambient)
        
        /// 创建一个地板
        let floor = SCNFloor()
        floor.firstMaterial?.diffuse.contents = "floor.jpeg"
        let floorNode = SCNNode(geometry: floor)
        scnView.scene?.rootNode .addChildNode(floorNode)
        
        
        
        /// 添加一个树模型
        let treeNode  = SCNScene(named: "palm_tree.dae")?.rootNode.childNode(withName: "tree", recursively: true)
        treeNode?.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -Float(M_PI/2))
        scene.rootNode.addChildNode(treeNode!)
        
        let constaint = SCNLookAtConstraint(target: treeNode)
         spotLight.constraints = [constaint]
        
        /// 贴图阴影
        spotLight.light?.castsShadow = false
        spotLight.light?.gobo?.contents = "mip.jpg"
        spotLight.light?.gobo?.intensity = 0.65
        spotLight.light?.shadowMode = .modulated
        
        
        
        
    }

   

}

