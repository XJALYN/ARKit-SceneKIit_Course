//
//  ViewController.m
//  OSSceneKit_004
//
//  Created by xu jie on 16/9/5.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
}

-(void)addSCNView{
    // 添加scenekit 游戏专用视图SCNView
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView .backgroundColor = [UIColor blackColor];
    [self.view addSubview:scnView ];
    scnView .allowsCameraControl = true; // 开启操纵照相机选项
    // 创建scene
    scnView .scene = [SCNScene scene];
    
    
    // 添加照相机
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode =[SCNNode node];
    cameraNode.camera = camera;
    cameraNode.position = SCNVector3Make(0, 0, 50);
    [scnView .scene.rootNode addChildNode:cameraNode];
    
    // 调节视角
//    camera.xFov = 20;
  //  camera.yFov = 20;
    
    // 调节焦距
    camera.focalDistance = 45;
    camera.focalBlurRadius = 1;
    
    // 设置正投影
//    camera.usesOrthographicProjection = true;
//    camera.orthographicScale = 100;
    
//    // 调节比例
//    camera.aperture = 10000;
    
    // 添加四方体
    
    SCNBox *box1 = [SCNBox boxWithWidth:10 height:10 length:10 chamferRadius:0];
    box1.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.png"];
    SCNNode *boxNode1 =[SCNNode node];
    boxNode1.geometry = box1;
    
    [scnView .scene.rootNode addChildNode:boxNode1];
    
    
    SCNBox *box2 = [SCNBox boxWithWidth:10 height:10 length:10 chamferRadius:0];
    box2.firstMaterial.diffuse.contents = [UIImage imageNamed:@"2.png"];
    SCNNode *boxNode2 =[SCNNode node];
    boxNode2.position = SCNVector3Make(0, 10, -20);
    boxNode2.geometry = box2;
    
    [scnView .scene.rootNode addChildNode:boxNode2];
    
}



@end
