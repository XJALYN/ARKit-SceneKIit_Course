//
//  ViewController.m
//  OSSceneKit_09
//
//  Created by xu jie on 16/9/10.
//  Copyright © 2016年 xujie. All rights reserved.
//


#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    [self addAdView];
    
}
-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}
-(void)addSCNView{
    SCNView *scnView  = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor blackColor];
    scnView.scene = [SCNScene scene];
    scnView.allowsCameraControl = TRUE;
    [self.view addSubview:scnView];
    
    // 创建摄像头
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;    camera.automaticallyAdjustsZRange = TRUE;
    cameraNode.position = SCNVector3Make(0, 10, 10);
    [scnView.scene.rootNode addChildNode:cameraNode];
    

    
//   
//    SCNNode *lightNode = [SCNNode node];
//    lightNode.light = [SCNLight light];
//    lightNode.light.type = SCNLightTypeDirectional;
//    lightNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/2.0);
//  
//   
//    [scnView.scene.rootNode addChildNode:lightNode];
    
    // 创建粒子系统
    
    // 增加一个木板
    
    SCNNode *floorNode = [SCNNode nodeWithGeometry:[SCNFloor floor]];
    floorNode.geometry.firstMaterial.diffuse.contents = @"floor.jpg";
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    [scnView.scene.rootNode addChildNode:floorNode];
    
    SCNBox *box = [SCNBox boxWithWidth:1 height:1 length:1 chamferRadius:0];
    box.firstMaterial.diffuse.contents = @"1.PNG";
    SCNNode *boxNode = [SCNNode nodeWithGeometry:box];
    boxNode.physicsBody =[SCNPhysicsBody staticBody];
    boxNode.position = SCNVector3Make(0, 10, 0);
    [scnView.scene.rootNode addChildNode:boxNode];
    
    SCNNode *text1 = [self createTextNodeWithString:@"酷"];
    SCNNode *text2 = [self createTextNodeWithString:@"走"];
    SCNNode *text3 = [self createTextNodeWithString:@"天"];
    SCNNode *text4 = [self createTextNodeWithString:@"涯"];
    
    [scnView.scene.rootNode addChildNode:text1];
    [scnView.scene.rootNode addChildNode:text2];
    [scnView.scene.rootNode addChildNode:text3];
    [scnView.scene.rootNode addChildNode:text4];
    
    // 创建连接行为
    SCNPhysicsHingeJoint *joint0 = [SCNPhysicsHingeJoint jointWithBodyA:boxNode.physicsBody axisA:SCNVector3Make(1, 0, 0) anchorA:SCNVector3Make(0, -0.5, 0) bodyB:text1.physicsBody axisB:SCNVector3Make(1, 0, 0) anchorB:SCNVector3Make(0.5, 1, 0)];
    
    SCNPhysicsHingeJoint *joint1 = [SCNPhysicsHingeJoint jointWithBodyA:text1.physicsBody axisA:SCNVector3Make(1, 0, 0) anchorA:SCNVector3Make(0, -0.5, 0) bodyB:text2.physicsBody axisB:SCNVector3Make(1, 0, 0) anchorB:SCNVector3Make(0, 0.5, 0)];
    SCNPhysicsHingeJoint *joint2 = [SCNPhysicsHingeJoint jointWithBodyA:text2.physicsBody axisA:SCNVector3Make(1, 0, 0) anchorA:SCNVector3Make(0, -0.5, 0) bodyB:text3.physicsBody axisB:SCNVector3Make(1, 0, 0) anchorB:SCNVector3Make(0, 0.5, 0)];
    SCNPhysicsHingeJoint *joint3 = [SCNPhysicsHingeJoint jointWithBodyA:text3.physicsBody axisA:SCNVector3Make(1, 0, 0) anchorA:SCNVector3Make(0, -0.5, 0) bodyB:text4.physicsBody axisB:SCNVector3Make(1, 0, 0) anchorB:SCNVector3Make(0, 0.5, 0)];

    
    [scnView.scene.physicsWorld addBehavior:joint0];
     [scnView.scene.physicsWorld addBehavior:joint1];
     [scnView.scene.physicsWorld addBehavior:joint2];
     [scnView.scene.physicsWorld addBehavior:joint3];

    
    

    
    
}

-(SCNNode*)createTextNodeWithString:(NSString*)string{
    SCNText *text = [SCNText textWithString:string extrusionDepth:1];
    text.font = [UIFont systemFontOfSize:1];
    text.firstMaterial.diffuse.contents = @"1.PNG";
    SCNNode *node =[SCNNode nodeWithGeometry:text];
    // 创建一个物理身体,使用指定的形状
    node.physicsBody = [SCNPhysicsBody bodyWithType:SCNPhysicsBodyTypeDynamic shape:[SCNPhysicsShape shapeWithGeometry:[SCNBox boxWithWidth:1 height:1 length:1 chamferRadius:0]options:nil]];
    

        SCNParticleSystem *particleSystem = [SCNParticleSystem particleSystemNamed:@"fire.scnp" inDirectory:nil];
        // 创建一个节点添加粒子系统
        SCNNode *particleNode = [SCNNode node];
        [particleNode addParticleSystem:particleSystem];
        particleNode.position = SCNVector3Make(0.5, 0, 0);
    
    [node addChildNode:particleNode];
    
    
    return node;
    
}




@end
