//
//  ViewController.m
//  OSSceneKit_god_03
//
//  Created by xu jie on 16/9/8.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet SCNView *scnView;
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UISlider *RSlider;
@property (weak, nonatomic) IBOutlet UISlider *GSlider;
@property (weak, nonatomic) IBOutlet UISlider *BSlider;


@property(strong,nonatomic)SCNNode *textNode;
@property(strong,nonatomic)SCNText *text;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 这是view的颜色和navigation的颜色一致
    self.scnView.backgroundColor = [UIColor colorWithRed:245/255.0 green:245/255.0 blue:245/255.0 alpha:1];
    
    //创建场景
    self.scnView.scene = [SCNScene scene];
    
    
    // 创建照相机
    SCNNode *cameraNode =[SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.position = SCNVector3Make(0, 0, 20);
    [self.scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加平行光
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.type = SCNLightTypeDirectional;
    [self.scnView.scene.rootNode addChildNode:lightNode];
    
    
    // 创建一个文字几何模型
  
    self.textNode = [SCNNode node];
    [self.scnView.scene.rootNode addChildNode:self.textNode];
    self.text = [SCNText textWithString:@"首页" extrusionDepth:3];
    self.text.font = [UIFont fontWithName:@"苹果" size:10];
    self.text.containerFrame = CGRectMake(-50, -15, 100, 20);
    self.text.wrapped = true;
     self.text.alignmentMode = kCAAlignmentCenter;
    self.text.firstMaterial.diffuse.contents = [UIColor blackColor];
    
    self.textNode.geometry = self.text;
    self.inputTextField.delegate = self;
    
    
    // 让字体旋转
    [self.textNode runAction:[SCNAction repeatActionForever:[SCNAction rotateByX:1 y:0 z:0 duration:1]]];
    
    [self addAdView];
     
   
    
    
    
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (IBAction)selectFont:(UIButton*)sender {
    
    self.text.firstMaterial.diffuse.contents = [UIColor redColor];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    self.text = [SCNText textWithString:textField.text extrusionDepth:3];
    self.text.font = [UIFont fontWithName:@"苹果" size:10];
    self.text.firstMaterial.diffuse.contents = [UIColor greenColor];
    self.text.containerFrame = CGRectMake(-50, -15, 100, 20);
    self.text.wrapped = true;
    self.text.alignmentMode = kCAAlignmentCenter;
    
    
    self.textNode.geometry = self.text;
    [textField resignFirstResponder];
    return true;
}

- (IBAction)sliderAction:(id)sender {
    
    self.text.firstMaterial.diffuse.contents = [UIColor colorWithRed:self.RSlider.value green:self.GSlider.value blue:self.BSlider.value alpha:1];
}




@end
