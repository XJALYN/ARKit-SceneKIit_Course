//
//  ViewController.m
//  OSSceneKit_07
//
//  Created by xu jie on 16/9/6.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

// 直接内容主要讲材质
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    
}

-(void)addSCNView{
    
    SCNView *scnView  = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor blackColor];
    scnView.scene = [SCNScene scene];
    scnView.allowsCameraControl = TRUE;
    [self.view addSubview:scnView];
    
    // 创建摄像头
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;
    camera.automaticallyAdjustsZRange = TRUE;
    cameraNode.position = SCNVector3Make(0, 0, 10);
    [scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加一个环境光
    
    SCNNode *ambientlightNode = [SCNNode node];
    ambientlightNode.light =[SCNLight light];
    ambientlightNode.light.type = SCNLightTypeDirectional;
    ambientlightNode.light.color = [UIColor whiteColor];
    [scnView.scene.rootNode addChildNode:ambientlightNode];
    
    // 添加一个灯光
//    SCNNode *spotLightNode = [SCNNode node];
//    spotLightNode.position = SCNVector3Make(0, 50, 0);
//    spotLightNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/2.0);
//    spotLightNode.light = [SCNLight light];
//    spotLightNode.light.color = [UIColor blackColor];
//    spotLightNode.light.type = SCNLightTypeSpot;
//    [scnView.scene.rootNode addChildNode:spotLightNode];
    
    // 添加球体
    
    SCNSphere *sphere = [SCNSphere sphereWithRadius:2];
    SCNNode *sphereNode = [SCNNode nodeWithGeometry:sphere];
    [scnView.scene.rootNode addChildNode:sphereNode];
    // 为什么可以像下面这样写,上面讲过了,你说你没记住
    
    
     sphere.firstMaterial.diffuse.contents =@"earth-diffuse.jpg" ;//@"earth-diffuse.jpg"
   
     sphere.firstMaterial.locksAmbientWithDiffuse = YES;
    sphere.firstMaterial.ambient.contents = @"earth-bump.png";
   // sphere.firstMaterial.ambientOcclusion.contents = [UIColor redColor];
    
    
  //  sphere.firstMaterial.specular.contents = @"earth-specular";
    
    // 法线属性
  //  sphere.firstMaterial.normal.contents = @"earth-bump.png";
    // 是否渲染每个顶点每个属性,提高渲染质量
  //  sphere.firstMaterial.litPerPixel = YES;
   // sphere.firstMaterial.blendMode = SCNBlendModeAlpha;
    
    // 反射
    //sphere.firstMaterial.reflective.contents = @"earth-reflective.jpg";//@[[UIImage imageNamed:@"1.PNG"],@"1.PNG",@"earth-diffuse.jpg",@"earth-diffuse.jpg",@"earth-diffuse.jpg",@"1.PNG"];//@"earth-reflective.jpg"
    // 影射因子
    //sphere.firstMaterial.fresnelExponent = 10;
    
    // 设置自身发光 但不会照亮别人
    //sphere.firstMaterial.emission.contents = @"earth-emissive.jpg";//@"earth-emissive.jpg"
   // sphere.firstMaterial.selfIllumination.contents = [UIColor blueColor];
    
    // 设置材质的透明度
//    sphere.firstMaterial.transparent.contents = @"cloudsTransparency.png";
//    sphere.firstMaterial.transparencyMode = SCNTransparencyModeRGBZero;
//    sphere.firstMaterial.transparency = 2;
   
//    sphere.firstMaterial.multiply.contents = [UIColor greenColor];
    
    // 让表明更加光滑
   // sphere.firstMaterial.shininess = 1000;
    
    // 是否两边都渲染
    
    //sphere.firstMaterial.doubleSided = true;
    //sphere.firstMaterial.cullMode = SCNCullFront;

//
//    SCNBox *box = [SCNBox boxWithWidth:5 height:5 length:5 chamferRadius:0];
//    SCNNode *boxNode = [SCNNode nodeWithGeometry:box];
//    
//    boxNode.position = SCNVector3Make(0, -15, 10);
//    [scnView.scene.rootNode addChildNode:boxNode];
    
    
}


@end
