//
//  ViewController.swift
//  SceneKit_high_06
//
//  Created by xu jie on 2016/10/17.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        /// 创建视图
        let scnView = SCNView(frame: self.view.bounds)
        self.view.addSubview(scnView)
        scnView.backgroundColor = UIColor.black
        
        /// 创建场景
        let scene = SCNScene()
        scnView.scene = scene
        
        /// 创建照相机
        let cameraNode  = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(x:0,y:0,z:0)
        scene.rootNode.addChildNode(cameraNode)
        
        /// 创建一个绑定几何体的节点
        let bindNode = SCNNode()
        scene.rootNode.addChildNode(bindNode)
        
        /// 下面是重点内容了
        /// 创建顶点坐标
        let vertex:[Float] = [-1,1,-5,
                              1,1,-5,
                              1,-1,-5,
                              -1,-1,-5]
        

        
       
        /// 创建接受顶点的对象
        let vertexSource = SCNGeometrySource(data: getData(array: vertex), semantic: SCNGeometrySource.Semantic.vertex, vectorCount: 4, usesFloatComponents: true, componentsPerVector: 3, bytesPerComponent: MemoryLayout<Float>.size, dataOffset: 0, dataStride: MemoryLayout<Float>.size*3)
        print(vertexSource.debugDescription)
        /// 创建纹理坐标
        let texture:[Float] = [0,0,
                             1,0,
                             1,1,
                             0,1]
        let textureSource = SCNGeometrySource(data: getData(array: texture), semantic: SCNGeometrySource.Semantic.texcoord, vectorCount: 4, usesFloatComponents: true, componentsPerVector: 2, bytesPerComponent: MemoryLayout<Float>.size, dataOffset:0, dataStride: MemoryLayout<Float>.size*2)
        /// 法线索引
        let normal:[Float] = [0,0,1,
                              0,0,1,
                              0,0,1,
                              0,0,1]
        let normalSource = SCNGeometrySource(data: getData(array: normal), semantic: SCNGeometrySource.Semantic.normal, vectorCount: 4, usesFloatComponents: true, componentsPerVector: 3, bytesPerComponent: MemoryLayout<Float>.size, dataOffset: 0, dataStride: MemoryLayout<Float>.size*3)
        
        /// 颜色坐标 
        let color:[Float] = [1,0,0,
                             0,1,0,
                             0,0,1,
                             1,1,1]
        let colorSource = SCNGeometrySource(data: getData(array: color), semantic: SCNGeometrySource.Semantic.color, vectorCount: 4, usesFloatComponents: true, componentsPerVector: 3, bytesPerComponent:  MemoryLayout<Float>.size, dataOffset: 0, dataStride: MemoryLayout<Float>.size*3)
        
        /// 创建顶点索引
        let indices:[GLint] = [0,1,2,0,2,3]
        let indicesElement = SCNGeometryElement(data: getData(array: indices), primitiveType: SCNGeometryPrimitiveType.triangleStrip, primitiveCount: indices.count, bytesPerIndex: MemoryLayout<GLint>.size)
       
        
        /// 创建几何体
        let geometry = SCNGeometry(sources: [vertexSource,textureSource,normalSource,colorSource], elements: [indicesElement])
   
        /// 绑定几何体
        bindNode.geometry = geometry
    }
    
    /// 获取数据
    func getData<T>(array:[T])->Data{
        let data:UnsafeMutableRawPointer = malloc(MemoryLayout<T>.size*array.count)
        data.initializeMemory(as: T.self, from:  array)
        return  NSData(bytesNoCopy: data, length: MemoryLayout<T>.size*array.count, freeWhenDone: true) as Data
    }


}

