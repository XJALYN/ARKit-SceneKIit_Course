//
//  ViewController.m
//  SceneKit_mid_07
//
//  Created by xu jie on 16/9/20.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()
@property(nonatomic,strong)SCNView *scnView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setup];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setup{
    self.scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    self.scnView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:self.scnView];
    
    self.scnView.scene = [SCNScene scene];
    
    SCNNode *sunNode = [SCNNode node];
    sunNode.geometry = [SCNSphere sphereWithRadius:3];
    sunNode.position = SCNVector3Make(0, 0, -100);
    sunNode.geometry.firstMaterial.diffuse.contents = [UIColor redColor];
    [self.scnView.scene.rootNode addChildNode:sunNode];
    
    // 添加一个灯光
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.type = SCNLightTypeOmni;
    [self.scnView.scene.rootNode addChildNode:lightNode];
    
    // 添加相机
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    [self.scnView.scene.rootNode addChildNode:cameraNode];
    // 使用方式1
//  [SCNTransaction setAnimationDuration:3.0];
//  sunNode.position = SCNVector3Make(0, 0, 0);
    
    [sunNode runAction:[SCNAction moveTo:SCNVector3Make(0, 0, 0) duration:20]];
    // 使用方式2
//    [SCNTransaction begin];
//    [SCNTransaction setAnimationDuration:20];
//    [SCNTransaction completionBlock];
//    sunNode.position = SCNVector3Make(0, 0, 0);
//    [SCNTransaction commit];
    
}


@end
