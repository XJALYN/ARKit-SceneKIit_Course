//
//  ViewController.m
//  OSSceneKit_03
//
//  Created by xu jie on 16/9/4.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()
@property(nonatomic,strong)SCNView *gameView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    [self addBoxNode];
    [self addLightNode];
    [self addAdView];
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

/**
 *  添加一个SCNView 类型的视图
 */
-(void)addSCNView{
    self.gameView = [[SCNView alloc]initWithFrame:self.view.bounds];
    self.gameView.backgroundColor = [UIColor blackColor];
    self.gameView.allowsCameraControl = true;
    [self.view addSubview:self.gameView];
    
    self.gameView.scene = [SCNScene scene];
    
}

-(void)addBoxNode{
    // 创建正方块
    SCNBox *box = [SCNBox boxWithWidth:0.5 height:0.5 length:0.5 chamferRadius:0];// 正方体
    //box.firstMaterial.diffuse.contents = [UIColor redColor];
    
    // 创建球体
    SCNSphere *sphere = [SCNSphere sphereWithRadius:0.1];// 我们设置它的圆角为长的一般，它就是球体
    //sphere.firstMaterial.diffuse.contents = [UIColor greenColor];

    // 把两个结合体绑定到节点上
    SCNNode *boxNode = [SCNNode node];
    boxNode.geometry = box;
    boxNode.position = SCNVector3Make(0, 0, -11); // 把节点的位置固定在(0,0,-11)
    SCNNode *sphereNode = [SCNNode node];
    sphereNode.geometry = sphere;
    sphereNode.position = SCNVector3Make(0, 0, -10); // 把节点的位置固定在(0,0,-11)
    
    // 添加节点到场景中去
    [self.gameView.scene.rootNode addChildNode:boxNode];
    [self.gameView.scene.rootNode addChildNode:sphereNode];
    
    NSArray *NODEs = [self.gameView.scene.rootNode childNodes];
    
    
}

/**
 *  添加一个摄像头
 */
-(void)addLightNode{
    SCNLight *light = [SCNLight light];// 创建光对象
    light.type = SCNLightTypeSpot;// 设置类型
    light.color = [UIColor yellowColor]; // 设置光的颜色
    light.castsShadow = TRUE;// 捕捉阴影
    light.spotOuterAngle = 2;
 
    light.zFar = 10; // 设置它最远能照射单位10 的地方,也就是说只能照到 球体的位置
    SCNNode *lightNode = [SCNNode node];
    lightNode.position = SCNVector3Make(0, 0, 0); // 设置光源节点的位置
    lightNode.light  = light;
    [self.gameView.scene.rootNode addChildNode:lightNode]; // 添加到场景中去
    
}



@end
