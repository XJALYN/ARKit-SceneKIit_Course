//
//  ViewController.swift
//  SceneKit_mid_10
//
//  Created by xu jie on 2016/10/21.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit
import GoogleMobileAds;

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        /// 创建游戏专用视图
        let scnView = SCNView(frame: self.view.bounds, options: [SCNView.Option.preferredRenderingAPI.rawValue:true])
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        print(scnView.renderingAPI.rawValue)
        
        /// 创建游戏场景
        let scene = SCNScene()
        scnView.scene = scene
        
        /// 创建照相机
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.camera?.zNear = 0
        scene.rootNode.addChildNode(cameraNode)
        
        /// 创建一个正方体添加到场景中去
        let box = SCNBox(width: 1, height: 1, length: 1, chamferRadius: 0)
        box.firstMaterial?.diffuse.contents = "1.png"
        let boxNode = SCNNode(geometry: box)
        boxNode.position = SCNVector3Make(0, 0, -2)
        scene.rootNode.addChildNode(boxNode)
        
        /// 增加一个环境光
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light?.type = .ambient
        ambientLightNode.light?.intensity = 0.1
        scene.rootNode.addChildNode(ambientLightNode)
        
//        
//        let filter = CIFilter(name: "CIGaussianBlur")!
//        filter.setDefaults()
//        filter.setValue(10, forKey: kCIInputRadiusKey)
//        let filter = CIFilter(name: "CIEdgeWork")!//CIPixellate
        
        
//         let filter = CIFilter(name: "CISepiaTone")!
//        // 2
//        filter.setDefaults()
//        filter.setValue(0.8, forKey: kCIInputIntensityKey)
//        
//        let filter = CIFilter(name: "CISepiaTone",
//                                      withInputParameters: [kCIInputIntensityKey: 5])!
       
        let filter1 = CIFilter(name: "CIPixellate",
            withInputParameters: [kCIInputScaleKey: 10.0])!
        
        let filter2 = CIFilter(name: "CIPhotoEffectProcess")!

        boxNode.filters = [filter1,filter2]
        
        self.addADView()

    }
    
    func addADView(){
        let bannerView = GADBannerView(frame:CGRect(x: 0, y: self.view.bounds.size.height-50, width: self.view.bounds.size.width, height: 50))
        self.view.addSubview(bannerView);
        bannerView.rootViewController = self
        bannerView.adUnitID = "ca-app-pub-3629819764559170/3550577647"
        bannerView.isAutoloadEnabled = true;
        bannerView.load(GADRequest())
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

