//
//  ViewController.m
//  OSSceneKit_09
//
//  Created by xu jie on 16/9/10.
//  Copyright © 2016年 xujie. All rights reserved.
//


// 本节的学习目标是学会使用粒子系统
#import "ViewController.h"
#import <SceneKit/SceneKit.h>



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    
}
-(void)addSCNView{
    SCNView *scnView  = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor blackColor];
    scnView.scene = [SCNScene scene];
    scnView.allowsCameraControl = TRUE;
    [self.view addSubview:scnView];
    
    // 创建摄像头
    SCNCamera *camera = [SCNCamera camera];
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;    camera.automaticallyAdjustsZRange = TRUE;
    cameraNode.position = SCNVector3Make(0, 0, 50);
    [scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加一个环境光
    
//    SCNNode *ambientlightNode = [SCNNode node];
//    ambientlightNode.light =[SCNLight light];
//    ambientlightNode.rotation = SCNVector4Make(1, 0, 0, M_PI/2.0);
//    ambientlightNode.light.type = SCNLightTypeOmni;
//    ambientlightNode.light.color = [UIColor whiteColor];
//    [scnView.scene.rootNode addChildNode:ambientlightNode];
    
    // 创建粒子系统

    
    // 增加一个木板
    
    SCNBox *box = [SCNBox boxWithWidth:10 height:10 length:10 chamferRadius:0];
    box.firstMaterial.diffuse.contents = @"1.PNG";
    SCNNode *boxNode = [SCNNode nodeWithGeometry:box];
    boxNode.position = SCNVector3Make(0, 10, -100);
    [scnView.scene.rootNode addChildNode:boxNode];
    
    // 创建粒子系统对象
    SCNParticleSystem *particleSystem = [SCNParticleSystem particleSystemNamed:@"fire.scnp" inDirectory:nil];
    // 创建一个节点添加粒子系统
    SCNNode *node = [SCNNode node];
    [node addParticleSystem:particleSystem];
    node.position = SCNVector3Make(0, -1, 0);
    
    // 将粒子系统节点设置为四方体的子节点
    [boxNode addChildNode:node];
    
    SCNAction *move = [SCNAction repeatActionForever:[SCNAction moveBy:SCNVector3Make(0, 0, 10) duration:1]];
    
    [boxNode runAction:move];
    
    cameraNode.constraints = @[[SCNLookAtConstraint lookAtConstraintWithTarget:boxNode ]];
    
    
}




@end
