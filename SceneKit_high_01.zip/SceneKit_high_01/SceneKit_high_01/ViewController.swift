//
//  ViewController.swift
//  SceneKit_high_01
//
//  Created by xu jie on 2016/10/16.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit
import GoogleMobileAds


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        setup()
        addADView()
        
    }
    
    func addADView(){
        let bannerView = GADBannerView(frame:CGRect(x: 0, y: self.view.bounds.size.height-50, width: self.view.bounds.size.width, height: 50))
        self.view.addSubview(bannerView);
        bannerView.rootViewController = self
        bannerView.adUnitID = "ca-app-pub-3629819764559170/3550577647"
        bannerView.load(GADRequest())
        bannerView.isAutoloadEnabled = true;
    }
    
    func setup(){
        let scnView = SCNView(frame: self.view.bounds)
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        
        let scene = SCNScene()
        scnView.scene = scene
        
        let map = SCNScene(named: "foldingMap.dae")?.rootNode.childNode(withName: "Map", recursively: true)
        map?.rotation = SCNVector4Make(1, 0, 0, -Float(M_PI))
        scene.rootNode.addChildNode(map!)
        
        /// 添加灯光
        let spotLight =  SCNNode()
        spotLight.light = SCNLight()
        spotLight.light?.type = .spot
        spotLight.position = SCNVector3Make(0, 0, 2000)
        spotLight.light?.color = UIColor.red
        scene.rootNode.addChildNode(spotLight)
        
        /// 使用GLSL
        let mapGeometry = try! String(contentsOf: Bundle.main.url(forResource: "wave", withExtension: "shader")!,encoding: String.Encoding.utf8)
        
        
        let mapFragment = try! String(contentsOf: Bundle.main.url(forResource: "mapFragment", withExtension: "shader")!, encoding: String.Encoding.utf8)
        print(mapFragment)
        
         let mapLight = try! String(contentsOf: Bundle.main.url(forResource: "mapLighting", withExtension: "shader")!, encoding: String.Encoding.utf8)
      
        
        map?.geometry?.shaderModifiers = [SCNShaderModifierEntryPoint.geometry:mapGeometry,SCNShaderModifierEntryPoint.lightingModel:mapLight]//,SCNShaderModifierEntryPoint.fragment:mapFragment,SCNShaderModifierEntryPoint.lightingModel:mapLight
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

