//
//  ViewController.m
//  OSSceneKit_God_01
//
//  Created by xu jie on 16/9/6.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@interface ViewController ()
@property(nonatomic,strong)SCNView *scnView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUp];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

-(void)setUp{
    self.scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    self.scnView.backgroundColor = [UIColor blackColor];
    self.scnView.scene = [SCNScene scene];
     [self.view addSubview:self.scnView];
    
    // 设置物理世界执行的速度
    self.scnView.scene.physicsWorld.speed = 5;
   
    
    // 设置视图刷新频率
    self.scnView.preferredFramesPerSecond = 60;
   
    
    // 添加照相机
    SCNCamera *camera = [SCNCamera camera];
    
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;
    cameraNode.position = SCNVector3Make(0, 10, 10);
    cameraNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/8.0);
    [self.scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加地板
    
    SCNFloor *floor = [SCNFloor floor];
    floor.firstMaterial.diffuse.contents = @"floor-frames.jpg";
    SCNNode *floorNode = [SCNNode nodeWithGeometry:floor];
    [self.scnView.scene.rootNode addChildNode:floorNode];
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    
    
    
    // 创建一个聚光灯
    
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.type = SCNLightTypeSpot;
    lightNode.position = SCNVector3Make(0, 100, 0);
    lightNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/2.0);
    [self.scnView.scene.rootNode addChildNode:lightNode];
    
    // 添加文字
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"酷"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"走"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"天"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"涯"]];
    
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"酷"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"走"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"天"]];
    [self.scnView.scene.rootNode addChildNode:[self createTextNode:@"涯"]];
    
    
}

-(SCNNode*)createTextNode:(NSString*) string{
    // 创建字体
    SCNText *text = [SCNText textWithString:string extrusionDepth:1];
    text.font = [UIFont systemFontOfSize:3];
    text.firstMaterial.diffuse.contents = @"1.PNG";
    
    //绑定到节点上
    SCNNode *textNode =[SCNNode nodeWithGeometry:text];
    // 创建物理身体
  
    
    // 随机节点位置
    textNode.position = SCNVector3Make(-arc4random_uniform(2)+5, 30, -5);
    return textNode;
    
}

@end
