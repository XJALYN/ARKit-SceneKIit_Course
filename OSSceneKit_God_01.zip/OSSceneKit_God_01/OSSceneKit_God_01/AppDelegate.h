//
//  AppDelegate.h
//  OSSceneKit_God_01
//
//  Created by xu jie on 16/9/6.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

