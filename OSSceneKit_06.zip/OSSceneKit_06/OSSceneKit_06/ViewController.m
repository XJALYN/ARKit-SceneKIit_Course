//
//  ViewController.m
//  OSSceneKit_06
//
//  Created by xu jie on 16/9/6.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
}

-(void)addSCNView{
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:scnView];
    scnView.allowsCameraControl = TRUE;
    
    scnView.scene = [SCNScene scene];
   
   
    
    // 1.创建照相机
    
    SCNNode *cameraNode =[SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.position = SCNVector3Make(0, 0, 8);
    [scnView.scene.rootNode addChildNode:cameraNode];
    
    // 2.创建正方体
//    SCNBox *box = [SCNBox boxWithWidth:1 height:1 length:1 chamferRadius:0];
//     box.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *boxNode = [SCNNode node];
//    boxNode.position = SCNVector3Make(0, 0, 0);
//    boxNode.geometry = box;
//    [scnView.scene.rootNode addChildNode:boxNode];
   
    
    // 3.创建平面
//    SCNPlane *plane =[SCNPlane planeWithWidth:2 height:2];
//    plane.firstMaterial.diffuse.contents = [UIImage imageNamed:@"2.PNG"];
//    SCNNode *planeNode = [SCNNode nodeWithGeometry:plane];
//    planeNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:planeNode];
    
    
    // 4.金子塔
    
//    SCNPyramid *pyramid = [SCNPyramid pyramidWithWidth:1 height:1 length:1];
//    pyramid.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *pyramidNode = [SCNNode nodeWithGeometry:pyramid];
//    pyramidNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:pyramidNode];
    
    // 5.球体
//    SCNSphere *sphere = [SCNSphere sphereWithRadius:1];
//    sphere.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *sphereNode =[SCNNode nodeWithGeometry:sphere];
//    sphereNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:sphereNode];
    
    // 6.圆柱体
    
//    SCNCylinder *cylinder = [SCNCylinder cylinderWithRadius:1 height:2];
//    cylinder.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *cylinderNode =[SCNNode nodeWithGeometry:cylinder];
//    cylinderNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:cylinderNode];
    
    // 7.圆锥体
    
//    SCNCone *cone = [SCNCone coneWithTopRadius:0 bottomRadius:1 height:1];
//    cone.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *coneNode = [SCNNode nodeWithGeometry:cone];
//    coneNode.position = SCNVector3Make(0,0, 0);
//    [scnView.scene.rootNode addChildNode:coneNode];
    
    // 8.管道
    
//    SCNTube *tube = [SCNTube tubeWithInnerRadius:1 outerRadius:1.2 height:2];
//    tube.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *tubeNode =[SCNNode nodeWithGeometry:tube];
//    tubeNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:tubeNode];
    
    // 9.胶囊
//    SCNCapsule *capsule = [SCNCapsule capsuleWithCapRadius:2 height:2 ];
//    capsule.firstMaterial.diffuse.contents = [UIImage imageNamed:@"2.PNG"];
//    SCNNode *capsuleNode = [SCNNode nodeWithGeometry:capsule];
//    capsuleNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:capsuleNode];
    
     //10.环面
//    SCNTorus *torus = [SCNTorus torusWithRingRadius:1 pipeRadius:0.5];
//    torus.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *torusNode = [SCNNode nodeWithGeometry:torus];
//    torusNode.position = SCNVector3Make(0, 0, 0);
//    [scnView.scene.rootNode addChildNode:torusNode];
    
    // 11.地板
    
//    SCNFloor *floor = [SCNFloor floor];
//    floor.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
//    SCNNode *floorNode = [SCNNode nodeWithGeometry:floor];
//    floorNode.position = SCNVector3Make(0, -5, 0);
//    [scnView.scene.rootNode addChildNode:floorNode];
    
    // 12.文字
    SCNText *text = [SCNText textWithString:@"好好学习" extrusionDepth:0.5];
    text.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
    text.font = [UIFont systemFontOfSize:1];
    
//    // 设置文字被包裹
//    text.wrapped = TRUE;
//    text.containerFrame = CGRectMake(0, 0, 5, 5);
//    text.alignmentMode=kCAAlignmentCenter; // 文字居中对齐
    
    // 倾斜角度
   
    
//    text.chamferProfile = [UIBezierPath bezierPathWithArcCenter:CGPointMake(0, 0) radius:0.1 startAngle:0 endAngle:M_PI clockwise:TRUE];
//    
//     text.chamferRadius = 0.1;
//    text.flatness = 3;
//    SCNNode *textNode  =[SCNNode nodeWithGeometry:text];
//    textNode.position = SCNVector3Make(-2, 0, 0);
//    [scnView.scene.rootNode addChildNode:textNode];
    
    // 14 绘制任意形状
    
    SCNShape *shape = [SCNShape shapeWithPath:[UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, 1, 1) cornerRadius:0.5] extrusionDepth:3];
    shape.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
    SCNNode *shapdeNode =[SCNNode nodeWithGeometry:shape];
    [scnView.scene.rootNode addChildNode:shapdeNode];
    
    
    
    
}


@end
