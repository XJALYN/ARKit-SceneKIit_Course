//
//  ViewController.m
//  OSSceneKit_mid_01
//
//  Created by xu jie on 16/9/8.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@import GoogleMobileAds;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setup];
    [self addAdView];
   
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

-(void)setup{
    //1.创建视图
    SCNView *scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor whiteColor];
    scnView.scene = [SCNScene scene];

    scnView.allowsCameraControl = true;
    [self.view addSubview:scnView];
    
    // 2.添加照相机
    
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.position = SCNVector3Make(0, 0, 200);
    

    cameraNode.camera = [SCNCamera camera];
     cameraNode.camera.automaticallyAdjustsZRange = true;
    [scnView.scene.rootNode addChildNode:cameraNode];
   
    
    // 3.添加一个方向光
//    
//    SCNNode *lightNode =[SCNNode node];
//    lightNode.light = [SCNLight light];
//    lightNode.light.type  = SCNLightTypeAmbient;
//    lightNode.light.color = [UIColor whiteColor];
//    lightNode.position = SCNVector3Make(0, 0, 100000);
//    [scnView.scene.rootNode addChildNode:lightNode];
//
    
    
    
    
    //2.添加球体节点
    
    
//    NSURL *url1 = [[NSBundle mainBundle]URLForResource:@"aaa" withExtension:@"dae"];
//     NSURL *url2 = [[NSBundle mainBundle]URLForResource:@"aaa2" withExtension:@"dae"];
//    SCNScene *scene1 = [SCNScene sceneWithURL:url1 options:nil error:nil];
//     SCNScene *scene2 = [SCNScene sceneWithURL:url2 options:nil error:nil];
//   SCNGeometry *g1 = [scene1.rootNode childNodeWithName:@"plane" recursively:true].geometry;
//   
//    SCNGeometry *g2 = [scene2.rootNode childNodeWithName:@"plane" recursively:true].geometry;
//    g1.firstMaterial.diffuse.contents = @"mapImage.png";
//    g2.firstMaterial.diffuse.contents = @"mapImage.png";
////
//    SCNNode *planeNode = [SCNNode node];
//    [scnView.scene.rootNode addChildNode:planeNode];
//    planeNode.geometry = g1;
//    [scnView.scene.rootNode addChildNode:planeNode];
//   
//    planeNode.morpher = [[SCNMorpher alloc]init];
//    planeNode.morpher.targets = @[g2];
//    [planeNode.morpher setWeight:1 forTargetAtIndex:0];
//   
//    
//    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"morpher.weights[0]"];
//    animation.fromValue = @0.0;
//    animation.toValue = @1.0;
//    animation.autoreverses = YES;
//    animation.repeatCount = INFINITY;
//    animation.duration = 2;
   // [planeNode addAnimation:animation forKey:nil];
    
     NSURL *url3 = [[NSBundle mainBundle]URLForResource:@"foldingMap" withExtension:@"dae"];
    SCNNode *node1 = [[SCNScene sceneWithURL:url3 options:nil error:nil].rootNode childNodeWithName:@"Map" recursively:true];
    node1.geometry.firstMaterial.diffuse.contents = @"1.PNG";
    [scnView.scene.rootNode addChildNode:node1];
    
    
    node1.rotation = SCNVector4Make(1, 0, 0, 2*M_PI);
//    node1.pivot = SCNMatrix4Rotate( node1.pivot, -M_PI, 0, 1, 0);
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"morpher.weights[0]"];
    animation.fromValue = @0.0;
    animation.toValue = @1.0;
    animation.autoreverses = YES;
    animation.repeatCount = INFINITY;
    animation.duration = 2;
    [node1 addAnimation:animation forKey:nil];
 
    
    
}

@end
