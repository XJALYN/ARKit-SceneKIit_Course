//
//  ViewController.swift
//  SceneKit_mid_08
//
//  Created by xu jie on 2016/10/15.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit
import GoogleMobileAds;

class ViewController: UIViewController,SCNPhysicsContactDelegate {
    var scene:SCNScene?
    var scnView:SCNView?
    override func viewDidLoad() {
        super.viewDidLoad()
        /// 初始化
        setup()
        addADView()
        
    }
    
    func addADView(){
        let bannerView = GADBannerView(frame:CGRect(x: 0, y: self.view.bounds.size.height-50, width: self.view.bounds.size.width, height: 50))
        self.view.addSubview(bannerView);
        bannerView.rootViewController = self
        bannerView.adUnitID = "ca-app-pub-3629819764559170/3550577647"
        bannerView.isAutoloadEnabled = true;
        bannerView.load(GADRequest())
        
    }
    
    //
    func setup(){
        /// 创建游戏专用视图
        let scnView = SCNView(frame: self.view.bounds)
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        self.scnView = scnView
        /// 创建一个场景
        let scene = SCNScene()
        
         scnView.scene = scene
        
        
        /// 创建一个照相机
        let cameraNode  = SCNNode()
        cameraNode.camera = SCNCamera()
        cameraNode.camera?.automaticallyAdjustsZRange = true
        cameraNode.position = SCNVector3(x: 0, y: 30, z: 30)
        cameraNode.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -Float(M_PI/4))
        scnView.scene?.rootNode.addChildNode(cameraNode)
        
        
        /// 创建一个球体
        
        let sphere = SCNSphere(radius: 1)
        sphere.firstMaterial?.diffuse.contents = UIColor.red
        let sphereNode = SCNNode(geometry: sphere)
        sphereNode.position = SCNVector3(x:0,y:2,z:0)
        scene.rootNode.addChildNode(sphereNode)
        
        /// 在球体上方添加一个正方体
        let box = SCNBox(width: 2, height: 2, length: 2, chamferRadius: 0)
        box.firstMaterial?.diffuse.contents = UIColor.blue
        let boxNode = SCNNode(geometry: box)
        boxNode.position = SCNVector3(x:0,y:20,z:0)
        scene.rootNode.addChildNode(boxNode)
        
        /// 创建一个地板
        let floor = SCNFloor()
        floor.firstMaterial?.diffuse.contents = "floor.jpg"
        let floorNode = SCNNode(geometry: floor)
        scene.rootNode.addChildNode(floorNode)
        
        /// 设置SCNView的代理
       

      
        floorNode.physicsBody = SCNPhysicsBody.static()
        sphereNode.physicsBody = SCNPhysicsBody.dynamic()
        boxNode.physicsBody = SCNPhysicsBody.dynamic()
//        boxNode.physicsBody?.collisionBitMask = 0x01
//        boxNode.physicsBody?.contactTestBitMask = 0x01
//        sphereNode.physicsBody?.collisionBitMask = 0x11
//        sphereNode.physicsBody?.contactTestBitMask = 0x01
        //scnView .prepare(scene, shouldAbortBlock: nil)
      
        sphereNode.physicsBody!.categoryBitMask = 0x12;
        sphereNode.physicsBody!.collisionBitMask = ~(0x12);
        boxNode.physicsBody!.categoryBitMask = 0x4;
        boxNode.physicsBody!.collisionBitMask = ~(0x4);
        boxNode.physicsBody?.velocity = SCNVector3Make(0, -10, 0)
        //sphereNode.physicsBody?.velocity = SCNVector3Make(0, 100, 0)
        
         scene.physicsWorld.contactDelegate = self
        
//        let tap = UITapGestureRecognizer(target: self, action: #selector(tapHandle(gesture:)))
//        scnView.addGestureRecognizer(tap)
        
        
       
        
        
    }
    func tapHandle(gesture:UITapGestureRecognizer){
        let results:[SCNHitTestResult] = (self.scnView?.hitTest(gesture.location(ofTouch: 0, in: self.scnView), options: nil))!
        guard let firstNode  = results.first else{
            return
        }
        // 点击到的节点
        print(firstNode.node)
    }
 
    
    
    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact){
        print(contact)
    }
    func physicsWorld(_ world: SCNPhysicsWorld, didUpdate contact: SCNPhysicsContact){
        print(contact)
    }
    
    func physicsWorld(_ world: SCNPhysicsWorld, didEnd contact: SCNPhysicsContact){
        print(contact)
    }
   
   
    
    
    
}

