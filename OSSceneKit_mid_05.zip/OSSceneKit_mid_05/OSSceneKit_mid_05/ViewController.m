//
//  ViewController.m
//  OSSceneKit_mid_05
//
//  Created by xu jie on 16/9/15.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()
@property(nonatomic,strong)SCNView *scnView;
@property(strong,nonatomic)SCNNode *floorNode;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUp];
    [self addAdView];
   
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

-(void)setUp{
    
    // 创建游戏视图和游戏场景
    self.scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    self.scnView.backgroundColor = [UIColor blackColor];
    self.scnView.scene = [SCNScene scene];
    [self.view addSubview:self.scnView];
    self.scnView.allowsCameraControl = true;
    
    // 创建照相机
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.position = SCNVector3Make(0, 30, 30);
    cameraNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/4);
    cameraNode.camera.automaticallyAdjustsZRange = true;
    [self.scnView.scene.rootNode addChildNode:cameraNode];
    
    // 创建一个地板
    SCNNode *floorNode = [SCNNode node];
    self.floorNode = floorNode;
    floorNode.geometry = [SCNFloor floor];
    floorNode.geometry.firstMaterial.diffuse.contents = @"floor.jpg";
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    [self.scnView.scene.rootNode addChildNode:floorNode];
    
    
    // 创建球体
//    int count = 60;
//    while (count) {
//        [self addBall];
//        count--;
//    }
//    
    // 让物理世界失重
  //  self.scnView.scene.physicsWorld.gravity = SCNVector3Make(0, 0, 0);
    
    [self addTube];

    self.scnView.scene.physicsWorld.speed = 10;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = self.view.bounds;
    [button addTarget:self action:@selector(addMagneticField) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    //[self addParticleSystem];
    
}

// MARK: - 添加球体
- (void)addBall{
    SCNNode *ballNode = [SCNNode node];
    ballNode.geometry = [SCNSphere sphereWithRadius:1];
    ballNode.geometry.firstMaterial.diffuse.contents = @"ball";
    ballNode.physicsBody = [SCNPhysicsBody dynamicBody];
    ballNode.position = SCNVector3Make(0, arc4random_uniform(2), arc4random_uniform(2)-1);
    [self.scnView.scene.rootNode addChildNode:ballNode];
}

// MARK: - 创建一个圆柱
-(void)addTube{
    SCNTube *tube = [SCNTube tubeWithInnerRadius:1 outerRadius:1.2 height:4];
    tube.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
    SCNNode *tubeNode =[SCNNode nodeWithGeometry:tube];
    tubeNode.physicsBody = [SCNPhysicsBody kinematicBody];
    tubeNode.position = SCNVector3Make(-5, 2, 0);
    [self.scnView.scene.rootNode addChildNode:tubeNode];
    
    SCNNode *tubeNode1 = [SCNNode nodeWithGeometry:[SCNTube tubeWithInnerRadius:4.5 outerRadius:5 height:2]];
    tubeNode1.geometry.firstMaterial.diffuse.contents = [UIImage imageNamed:@"1.PNG"];
    tubeNode1.position = SCNVector3Make(6, 1, 0);
    [self.scnView.scene.rootNode addChildNode:tubeNode1];
    
    // 添加特效
    
    SCNParticleSystem *particleSytem = [SCNParticleSystem particleSystemNamed:@"fire.scnp" inDirectory:nil];
    particleSytem.colliderNodes = @[tubeNode1,self.floorNode];
    particleSytem.affectedByPhysicsFields = true;
    particleSytem.particleCharge = 10;
  
    
   
    SCNNode *particleNode = [SCNNode node];
    particleNode.position = SCNVector3Make(0, 0, 0);
    [particleNode addParticleSystem:particleSytem];
    particleNode.physicsBody = [SCNPhysicsBody dynamicBody];
    [tubeNode addChildNode:particleNode];
    
    
    // 添加旋转力
    
  
    

    
    
    // 添加磁场力
    
    SCNNode *electricFieldNode = [SCNNode node];
    electricFieldNode.physicsField = [SCNPhysicsField electricField];
    electricFieldNode.physicsField.strength = -10;
    [tubeNode1 addChildNode:electricFieldNode];
    

    
    

    
    
}

// MARK: - 添加一个正方体

-(void)addBox{
    
    SCNNode *boxNode = [SCNNode node];
    boxNode.geometry = [SCNBox boxWithWidth:4 height:4 length:4 chamferRadius:0];
    boxNode.geometry.firstMaterial.diffuse.contents = [UIColor redColor];
    boxNode.physicsBody = [SCNPhysicsBody dynamicBody];
    boxNode.position = SCNVector3Make(0, 30, 0);
    boxNode.physicsBody.velocity = SCNVector3Make(0, 0, 0);
    [self.scnView.scene.rootNode addChildNode:boxNode];
    boxNode.physicsBody.charge = 10;
    
    // 创建一个拖拽力
//    SCNNode *drayFieldNode = [SCNNode node];
//    drayFieldNode.physicsField = [SCNPhysicsField dragField];
//    drayFieldNode.physicsField.strength = 30;
//    drayFieldNode.physicsField.direction = SCNVector3Make(0, -1, 0);
//    [boxNode addChildNode:drayFieldNode];
    

//    

    
}

// MARK: - 添加重力

-(void)addGravity{
     self.scnView.scene.physicsWorld.gravity = SCNVector3Make(0, - 9.8, 0);
}

// MARK: - 添加旋转力

- (void)addVortexField{
    SCNNode *vortexFieldNode = [SCNNode node];
    vortexFieldNode.physicsField = [SCNPhysicsField vortexField];
    vortexFieldNode.physicsField.strength = -10;
    vortexFieldNode.physicsField.direction = SCNVector3Make(-1, 0, 0);
    [self.scnView.scene.rootNode addChildNode:vortexFieldNode];
}

// MARK: - 创建一个朝向中心加速的力

-(void)addRadialGravity{
    SCNNode *radialGravityNode = [SCNNode node];
    radialGravityNode.physicsField = [SCNPhysicsField radialGravityField];
    radialGravityNode.physicsField.strength = -1000;
    radialGravityNode.position = SCNVector3Make(0, 0, 0);
    [self.scnView.scene.rootNode addChildNode:radialGravityNode];
}

// MARK: - 创建线性力

-(void)addLineGravity{
    SCNNode *lineGravityNode = [SCNNode node];
    lineGravityNode.physicsField = [SCNPhysicsField linearGravityField];
    lineGravityNode.physicsField.strength = 1;
    lineGravityNode.physicsField.direction = SCNVector3Make(0, 0, -1);
    [self.scnView.scene.rootNode addChildNode:lineGravityNode];
}

// MARK : - 创建随机的力

-(void)addNoiseField{
    SCNNode *noiseFieldNode = [SCNNode node];
    //noiseFieldNode.physicsField = [SCNPhysicsField noiseFieldWithSmoothness:0 animationSpeed:1];
    noiseFieldNode.physicsField  = [SCNPhysicsField turbulenceFieldWithSmoothness:0 animationSpeed:1];
    noiseFieldNode.physicsField.strength = 5;
    [self.scnView.scene.rootNode addChildNode:noiseFieldNode];
    
}

// MARK: - 创建一种和速度成正比的随机力

-(void)addTurbulenceField{
    SCNNode *turbulenceFieldNode = [SCNNode node];
    turbulenceFieldNode.physicsField  = [SCNPhysicsField turbulenceFieldWithSmoothness:0 animationSpeed:1];
    turbulenceFieldNode.physicsField.strength = 5;
    [self.scnView.scene.rootNode addChildNode:turbulenceFieldNode];
}

// MARK: - 添加粒子效果
-(void)addParticleSystem{
    SCNParticleSystem *particleSytem = [SCNParticleSystem particleSystemNamed:@"smoke.scnp" inDirectory:nil];
    SCNNode *particleNode = [SCNNode node];
    particleNode.position = SCNVector3Make(0, 100, 0);
    [particleNode addParticleSystem:particleSytem];
    particleNode.physicsBody = [SCNPhysicsBody dynamicBody];
    
    [self.scnView.scene.rootNode addChildNode:particleNode];
}

// MARK: - 弹簧力

-(void)addSpringField{
    SCNNode *springField = [SCNNode node];
    springField.physicsField = [SCNPhysicsField springField];
    springField.physicsField.strength = 0.01;
    springField.position = SCNVector3Make(0, 30, 0);
    [self.scnView.scene.rootNode addChildNode:springField];
}

// MARK: - 电厂的大小

-(void)addElectricField{
    SCNNode *electricFieldNode = [SCNNode node];
    electricFieldNode.physicsField = [SCNPhysicsField electricField];
    electricFieldNode.physicsField.strength = 10;
    [self.scnView.scene.rootNode addChildNode:electricFieldNode];
    
}

// MARK: - 磁场
- (void)addMagneticField{
    SCNNode *magneticFielddNode = [SCNNode node];
    magneticFielddNode.physicsField = [SCNPhysicsField magneticField];
    magneticFielddNode.physicsField.strength = -0.5;
    [self.scnView.scene.rootNode addChildNode:magneticFielddNode];
}


@end
