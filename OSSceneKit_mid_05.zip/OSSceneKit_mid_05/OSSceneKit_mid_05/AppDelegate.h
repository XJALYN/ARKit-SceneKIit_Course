//
//  AppDelegate.h
//  OSSceneKit_mid_05
//
//  Created by xu jie on 16/9/15.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

