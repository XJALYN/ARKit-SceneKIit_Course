//
//  ViewController.m
//  OSSceneKit_01
//
//  Created by xu jie on 16/9/2.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet SCNView *myView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 获取文件所在的路径
    NSURL *url = [[NSBundle mainBundle]URLForResource:@"yizi" withExtension:@"dae"];
   // 创建场景
    SCNScene *scene = [SCNScene sceneWithURL:url options:nil error:nil];
    
    
    self.myView.scene = scene;
    self.myView.backgroundColor = [UIColor blackColor];
    
    // 打开操控
    self.myView.allowsCameraControl =  TRUE;
    
    
   
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
