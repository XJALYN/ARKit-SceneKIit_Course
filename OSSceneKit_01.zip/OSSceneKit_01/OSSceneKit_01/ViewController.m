//
//  ViewController.m
//  OSSceneKit_01
//
//  Created by xu jie on 16/9/2.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
@import GoogleMobileAds;

@interface ViewController ()
@property (weak, nonatomic) IBOutlet SCNView *myView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 获取文件所在的路径
    NSURL *url = [[NSBundle mainBundle]URLForResource:@"yizi" withExtension:@"dae"];
   // 创建场景
    SCNScene *scene = [SCNScene sceneWithURL:url options:nil error:nil];
    
    
    self.myView.scene = scene;
    self.myView.backgroundColor = [UIColor blackColor];
    
    // 打开操控
    self.myView.allowsCameraControl =  TRUE;
    
    
    [self addAdView];
   
}

-(void)addAdView{
    GADBannerView *bannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 50)];
    [self.view addSubview:bannerView];
    bannerView.adUnitID = @"ca-app-pub-3629819764559170/3550577647";
    bannerView.rootViewController = self;
    bannerView.autoloadEnabled = true;
    GADRequest *request = [GADRequest request];
    [ bannerView loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
