//
//  ViewController.m
//  OSSceneKit_mid_04
//
//  Created by xu jie on 16/9/13.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()<SCNSceneRendererDelegate>{
    SCNView * scnView;
    SCNIKConstraint *ikContrait;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
}

- (void)addSCNView{
    // 创建场景和视图
    scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    scnView.backgroundColor = [UIColor blackColor];
    scnView.allowsCameraControl = true;
    scnView.scene = [SCNScene scene];
    scnView.scene.physicsWorld.gravity = SCNVector3Make(0, 90, 0);
    [self.view addSubview:scnView];
    
    // 创建照相机
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.camera.automaticallyAdjustsZRange = true;
    cameraNode.position = SCNVector3Make(0, 0,1000);
    [scnView.scene.rootNode addChildNode:cameraNode];
    scnView.delegate = self;
  
    [self addArmToScene];
    
    
    
    // 添加手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapHandle)];
    [scnView addGestureRecognizer:tap];
    
    
}

-(void)addArmToScene{
    
    // 创建手掌
    SCNNode *handNode = [SCNNode node];
    handNode.geometry = [SCNBox boxWithWidth:20 height:20 length:20 chamferRadius:0];
    handNode.geometry.firstMaterial.diffuse.contents = [UIColor purpleColor];
    handNode.position = SCNVector3Make(0, -50, 0);
    
    // 创建小手臂
    SCNNode *lowerArm = [SCNNode node];
    lowerArm.geometry = [SCNCylinder cylinderWithRadius:1 height:100];
    lowerArm.geometry.firstMaterial.diffuse.contents = [UIColor redColor];
    lowerArm.position = SCNVector3Make(0, -50, 0);
    lowerArm.pivot = SCNMatrix4MakeTranslation(0, 50, 0); // 连接点
    [lowerArm addChildNode:handNode];
    
    // 创建上臂
    SCNNode *upperArm = [SCNNode node];
    upperArm.geometry = [SCNCylinder cylinderWithRadius:1 height:100];
    upperArm.geometry.firstMaterial.diffuse.contents = [UIColor greenColor];
    upperArm.pivot = SCNMatrix4MakeTranslation(0, 50, 0);
    [upperArm addChildNode:lowerArm];
    
    // 创建控制点
    SCNNode *controlNode = [SCNNode node];
    controlNode.geometry = [SCNSphere sphereWithRadius:10];
    controlNode.geometry.firstMaterial.diffuse.contents = [UIColor blueColor];
    [controlNode addChildNode:upperArm];
    controlNode.position= SCNVector3Make(0, 100, 0);
    
    // 添加到场景中去
    [scnView.scene.rootNode addChildNode:controlNode];
    scnView.delegate = self;

    // 创建约束
     ikContrait =[SCNIKConstraint inverseKinematicsConstraintWithChainRootNode:controlNode];
    
    // 给执行器添加约束
    handNode.constraints = @[ikContrait];
}

-(void)tapHandle{
    [self createNodeToScene:scnView.scene andConstraint:ikContrait];
}

-(void)createNodeToScene:(SCNScene*)scene andConstraint:(SCNIKConstraint*)ikConstrait{
    SCNNode *node = [SCNNode node];
    node.position = SCNVector3Make(arc4random_uniform(100), arc4random_uniform(100), arc4random_uniform(100));
    [scene.rootNode addChildNode:node];
    node.geometry = [SCNSphere sphereWithRadius:10];
    node.geometry.firstMaterial.diffuse.contents = [UIColor colorWithRed:arc4random_uniform(255.0)/255.0 green:arc4random_uniform(255.0)/255.0 blue:arc4random_uniform(255.0)/255.0 alpha:1];
    // 创建动画，当手掌接触到小球时,给小球添加一个动态身体
    [SCNTransaction begin];
    [SCNTransaction setAnimationDuration:0.5];
    ikConstrait.targetPosition = node.position;
    [SCNTransaction commit];
    node.physicsBody = [SCNPhysicsBody dynamicBody];
    
}





@end
