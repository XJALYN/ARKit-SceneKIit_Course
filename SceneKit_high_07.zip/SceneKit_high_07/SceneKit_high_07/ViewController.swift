//
//  ViewController.swift
//  SceneKit_high_07
//
//  Created by xu jie on 2016/10/20.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit

class ViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /// 创建游戏专用视图
        let scnView = SCNView(frame: self.view.bounds, options: [SCNView.Option.preferredRenderingAPI.rawValue:true])
       
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        print(scnView.renderingAPI.rawValue)
     
        /// 创建游戏场景
        let scene = SCNScene()
        scnView.scene = scene
        
        /// 创建照相机
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        /// 创建一个文字节点
        let text = SCNText(string: "酷走天涯", extrusionDepth: 1)
        text.font = UIFont.systemFont(ofSize: 1)
        let textNode = SCNNode(geometry: text)
        textNode.position = SCNVector3Make(-2, -0.5, -5)
        scene.rootNode.addChildNode(textNode)
        
        /// 增加一个环境光
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light?.type = .ambient
        scene.rootNode.addChildNode(ambientLightNode)
       
        /* 下面是重点内容了*/
        
//        /// 1.创建一个加载着色器程序的对象
        let program = SCNProgram()
         program.isOpaque = false
        
        /// 2.将定义着色器和片段着色器加载进来
        let vertexShader   = Bundle.main.url(forResource: "CustomProgram", withExtension:"vsh")
        let fragmentShader = Bundle.main.url(forResource: "CustomProgram", withExtension:"fsh")
        
        do {
            program.vertexShader =   try String(contentsOf: vertexShader!, encoding: String.Encoding.utf8)
            program.fragmentShader = try String(contentsOf: fragmentShader!, encoding: String.Encoding.utf8)

        }catch{
            print(error)
        }
        
        /// 3.将绑定顶点着色器的属性和几何体进行绑定
        program.setSemantic(SCNGeometrySource.Semantic.vertex.rawValue, forSymbol: "a_srcPos", options: nil)
        program.setSemantic(SCNGeometrySource.Semantic.texcoord.rawValue, forSymbol: "a_texcoord", options: nil)
        
        /// 4.绑定矩阵变换的属性
        program.setSemantic(SCNModelViewTransform, forSymbol: "u_mv", options: nil)
        program.setSemantic(SCNProjectionTransform, forSymbol: "u_proj", options: nil)
        
        
        /// 5.给材质设置着色器程序
        textNode.geometry?.firstMaterial?.program = program
        
        /// 6.设置块变量的值的方法如下
        var morphFactor:Float = 0
        textNode.geometry?.firstMaterial?.handleBinding(ofSymbol: "factor", handler:  { (programID, location, renderedNode, renderer)  in
            morphFactor += 0.01
            glUniform1f(GLint(location),  morphFactor);
           
        })

        
      
        textNode.geometry?.firstMaterial?.writesToDepthBuffer = false
        textNode.geometry?.firstMaterial?.readsFromDepthBuffer = false
        textNode.renderingOrder = 100 // 必须最后渲染
        let move = SCNAction.moveBy(x: 0, y: 0, z: -10, duration: 10)
        textNode.runAction(move)
        

    
       
       
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

