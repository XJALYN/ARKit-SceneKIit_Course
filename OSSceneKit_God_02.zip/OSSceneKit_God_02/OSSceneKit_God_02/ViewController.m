//
//  ViewController.m
//  OSSceneKit_God_02
//
//  Created by xu jie on 16/9/6.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"
#import <SceneKit/SceneKit.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet SCNView *scnView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUp];
}

-(void)setUp{
    
    self.scnView.backgroundColor = [UIColor blackColor];
    self.scnView.scene = [SCNScene scene];
  
    
    // 设置物理世界执行的速度
    self.scnView.scene.physicsWorld.speed = 5;
    
    
    // 设置视图刷新频率
    self.scnView.preferredFramesPerSecond = 60;
    
    
    // 添加照相机
    SCNCamera *camera = [SCNCamera camera];
    
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = camera;
    cameraNode.position = SCNVector3Make(0, 5, 10);

    [self.scnView.scene.rootNode addChildNode:cameraNode];
    
    // 添加地板
    
    SCNFloor *floor = [SCNFloor floor];
    floor.firstMaterial.diffuse.contents = @"floor-frames.jpg";
    SCNNode *floorNode = [SCNNode nodeWithGeometry:floor];
    [self.scnView.scene.rootNode addChildNode:floorNode];
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    
    
    
    // 创建一个聚光灯
    
    SCNNode *lightNode = [SCNNode node];
    lightNode.light = [SCNLight light];
    lightNode.light.type = SCNLightTypeSpot;
    lightNode.position = SCNVector3Make(0, 20, 20);
    lightNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/4);
    [self.scnView.scene.rootNode addChildNode:lightNode];
    
    // 创建一个环境光
//    SCNLight *light1 = [SCNLight light];
//    light1.type = SCNLightTypeAmbient;
//    SCNNode *lightNode1 = [SCNNode node];
//    lightNode.light = light1;
//    [self.scnView.scene.rootNode addChildNode:lightNode1]; 
    
    
    // 添加文字
    
    // 创建一个定时器,产生弹幕
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(createTextNode) userInfo:nil repeats:true];

    
    
}

-(void)createTextNode{
    // 创建字体
    SCNText *text = [SCNText textWithString:@"我是弹幕" extrusionDepth:1];
    text.firstMaterial.diffuse.contents = [UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0  blue:arc4random_uniform(255)/255.0  alpha:1];
    text.font = [UIFont systemFontOfSize:2];
    text.firstMaterial.diffuse.contents = @"1.PNG";
    
    //绑定到节点上
    SCNNode *textNode =[SCNNode nodeWithGeometry:text];
   
    
    // 随机节点位置
    textNode.position = SCNVector3Make(-arc4random_uniform(30)+15, arc4random_uniform(20)+1, -100);
    
    // 添加行为动画
    SCNAction *moveAction = [SCNAction moveTo:SCNVector3Make(-2, 4, 10) duration:5];
    SCNAction *removeFromSuper = [SCNAction removeFromParentNode];
    SCNAction *customAction = [SCNAction sequence:@[moveAction,removeFromSuper]];
    
    // 将节点添加到场景中去
    [self.scnView.scene.rootNode addChildNode:textNode];
    [textNode runAction:customAction];
   
    
}

@end
