//
//  ViewController.m
//  OSSceneKit_mid_06
//
//  Created by xu jie on 16/9/15.
//  Copyright © 2016年 xujie. All rights reserved.
//

// 学习目标
// 本节我们学习场景切换

#import "ViewController.h"
#import <SceneKit/SceneKit.h>
#import <SpriteKit/SpriteKit.h>

@interface ViewController ()
@property(nonatomic,strong)SCNView *scnView;
@property(strong,nonatomic)SCNNode *floorNode;
@property(strong,nonatomic)SCNScene *lastScene;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addScnView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

-(void)addScnView{
    
    // 创建游戏视图和游戏场景
    self.scnView = [[SCNView alloc]initWithFrame:self.view.bounds];
    self.scnView.backgroundColor = [UIColor blackColor];
    self.scnView.scene = [SCNScene scene];
    [self.view addSubview:self.scnView];
    self.scnView.allowsCameraControl = true;
    
    // 创建照相机
    SCNNode *cameraNode = [SCNNode node];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.position = SCNVector3Make(0, 30, 30);
    cameraNode.rotation = SCNVector4Make(1, 0, 0, -M_PI/4);
    cameraNode.camera.automaticallyAdjustsZRange = true;
    [self.scnView.scene.rootNode addChildNode:cameraNode];
    
    // 创建照相机
  
    
    // 创建一个地板
    SCNNode *floorNode = [SCNNode node];
    self.floorNode = floorNode;
    floorNode.geometry = [SCNFloor floor];
    floorNode.geometry.firstMaterial.diffuse.contents = @"floor.jpg";
    floorNode.physicsBody = [SCNPhysicsBody staticBody];
    [self.scnView.scene.rootNode addChildNode:floorNode];
    
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
//    button.frame = self.view.bounds;
//    [button addTarget:self action:@selector(presentScene1) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:button];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(presentScene1)];
    [self.scnView addGestureRecognizer:tap];
}


- (void)presentScene1{
    
    // 创建目标转换场景
    SCNScene *scene = [SCNScene scene];
    [scene.rootNode addChildNode:[[SCNScene sceneNamed:@"palm_tree.dae"].rootNode childNodeWithName:@"PalmTree" recursively:true]];
    // 添加一个照相机
    SCNNode *cameraNode1 = [SCNNode node];
    cameraNode1.camera = [SCNCamera camera];
    cameraNode1.position = SCNVector3Make(0, -100, -1000);
    cameraNode1.rotation = SCNVector4Make(1, 0, 0, M_PI);
    cameraNode1.camera.automaticallyAdjustsZRange = true;
    [scene.rootNode addChildNode:cameraNode1];
    
    // 引用上一个场景
    self.lastScene = self.scnView.scene;
    
    // 创建转换场景
    SKTransition *transition = [SKTransition doorwayWithDuration:1];
    [self.scnView presentScene:scene withTransition: transition incomingPointOfView:cameraNode1 completionHandler:^{
       
    }];

  
    
}

@end
