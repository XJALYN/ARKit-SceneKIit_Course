//
//  ViewController.swift
//  SceneKit_high_08
//
//  Created by xu jie on 2016/11/3.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let scnView = SCNView(frame: self.view.bounds, options: [SCNView.Option.preferredRenderingAPI.rawValue:true])
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        
        let scene = SCNScene()
        scnView.scene = scene
        scene.background.contents = "skybox01_cube.png"
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        scnView.allowsCameraControl = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

