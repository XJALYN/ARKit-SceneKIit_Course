//
//  ViewController.swift
//  SceneKit_high_08
//
//  Created by xu jie on 2016/11/3.
//  Copyright © 2016年 xujie. All rights reserved.
//

import UIKit
import SceneKit
import GoogleMobileAds

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let scnView = SCNView(frame: self.view.bounds, options: [SCNView.Option.preferredRenderingAPI.rawValue:true])
        scnView.backgroundColor = UIColor.black
        self.view.addSubview(scnView)
        
        let scene = SCNScene()
        scnView.scene = scene
        scene.background.contents = "skybox01_cube.png"
        
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        scnView.allowsCameraControl = true
        
        addADView()
    }
    
    func addADView(){
        let bannerView = GADBannerView(frame:CGRect(x: 0, y: self.view.bounds.size.height-50, width: self.view.bounds.size.width, height: 50))
        self.view.addSubview(bannerView);
        bannerView.rootViewController = self
        bannerView.adUnitID = "ca-app-pub-3629819764559170/3550577647"
        bannerView.isAutoloadEnabled = true;
        bannerView.load(GADRequest())
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

