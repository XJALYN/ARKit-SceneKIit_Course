//
//  ViewController.m
//  OSSceneKit_02
//
//  Created by xu jie on 16/9/3.
//  Copyright © 2016年 xujie. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(nonatomic,strong)SCNView *gameView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSCNView];
    [self createScene];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

- (void)addSCNView{
    // 1.创建一个边长为300 的视图，放在屏幕中心
    self.gameView = [[SCNView alloc]initWithFrame:CGRectMake(0, 0, 300, 300)];
    self.gameView.center = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));
    // 2.设置背景颜色为黑色
    self.gameView.backgroundColor = [UIColor blackColor];
    // 3.添加到父视图中去
    [self.view addSubview:self.gameView];
    self.gameView.allowsCameraControl = true;
}

-(void)createScene{
    SCNScene *scene = [SCNScene scene];
    self.gameView.scene = scene;
    
    SCNNode *node = [SCNNode node];
    [scene.rootNode addChildNode:node];
    
    // 创建一个球体几何绑定到节点上去
    SCNSphere *sphere = [SCNSphere sphereWithRadius:0.5];
    node.geometry = sphere;
    
    // 创建子节点 给子节点添加几何形状
    SCNNode *childNode = [SCNNode node];
    // 设置节点的位置
    childNode.position = SCNVector3Make(-0.5, 0, 1);
    // 设置几何形状，我们选择立体字体
    SCNText *text = [SCNText textWithString:@"加群学习:578734141" extrusionDepth:0.03];
    // 设置字体颜色
    text.firstMaterial.diffuse.contents = [UIColor redColor];
    // 设置字体大小
    text.font = [UIFont systemFontOfSize:0.15];
    // 给几点绑定几何物体
    childNode.geometry = text;
    [node addChildNode:childNode];
    
    
}



@end
